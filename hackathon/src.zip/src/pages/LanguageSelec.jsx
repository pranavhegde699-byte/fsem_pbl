
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=Instrument+Serif:ital@0;1&family=Noto+Sans+Devanagari:wght@400;600&family=Noto+Sans+Tamil:wght@400;600&family=Noto+Sans+Telugu:wght@400;600&family=Noto+Sans+Kannada:wght@400;600&display=swap');

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:#F7F4EF;min-height:100vh;display:flex;flex-direction:column;-webkit-font-smoothing:antialiased}

@keyframes fadeUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
@keyframes checkIn{0%{transform:scale(0);opacity:0}70%{transform:scale(1.2)}100%{transform:scale(1);opacity:1}}
@keyframes borderPulse{0%,100%{border-color:#C5B5A0}50%{border-color:#8B7355}}

.page-enter{animation:fadeUp .5s ease both}
.a2{animation:fadeUp .5s ease both .1s}
.a3{animation:fadeUp .5s ease both .2s}
.a4{animation:fadeUp .5s ease both .3s}

.lang-card{
  position:relative;
  background:#FFFFFF;
  border:1.5px solid #E8E2D9;
  border-radius:16px;
  padding:24px 18px 20px;
  cursor:pointer;
  display:flex;flex-direction:column;align-items:center;gap:10px;
  transition:border-color .2s, box-shadow .2s, transform .2s;
  text-align:center;
}
.lang-card:hover{
  border-color:#C5B5A0;
  box-shadow:0 4px 20px rgba(139,115,85,.1);
  transform:translateY(-2px);
}
.lang-card.selected{
  border-color:#8B7355;
  border-width:2px;
  box-shadow:0 6px 28px rgba(139,115,85,.18);
  background:#FFFCF8;
  animation:borderPulse 2.5s ease-in-out infinite;
}
.check-dot{
  position:absolute;top:12px;right:12px;
  width:22px;height:22px;border-radius:50%;
  background:#8B7355;
  display:flex;align-items:center;justify-content:center;
  animation:checkIn .25s cubic-bezier(.34,1.56,.64,1) both;
}
.script-text{
  font-size:22px;font-weight:600;line-height:1.2;color:#2C2416;
}
.lang-label{
  font-size:11px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;color:#A89880;
}
.lang-code-pill{
  background:#F5F0E8;border-radius:6px;
  padding:3px 9px;font-size:10px;font-weight:700;
  letter-spacing:1px;color:#A89880;text-transform:uppercase;
  margin-top:2px;
}
.lang-card.selected .lang-code-pill{background:#EDE5D8;color:#7A6245}

.btn{
  width:100%;padding:15px;border-radius:12px;
  font-family:'DM Sans',sans-serif;font-size:15px;font-weight:600;
  letter-spacing:.3px;cursor:pointer;transition:all .2s;border:none;
}
.btn-primary{background:#2C2416;color:#F7F4EF;}
.btn-primary:hover{background:#3D3220;box-shadow:0 6px 20px rgba(44,36,22,.25);transform:translateY(-1px)}
.btn-primary:disabled{background:#C5B5A0;cursor:not-allowed;transform:none;box-shadow:none}
.btn-ghost{background:transparent;color:#A89880;border:1.5px solid #E8E2D9;margin-top:10px}
.btn-ghost:hover{border-color:#C5B5A0;color:#8B7355}

.step-bar{display:flex;align-items:center;gap:0}
.step-seg{height:3px;flex:1;background:#E8E2D9;transition:background .3s}
.step-seg.done{background:#8B7355}
.step-seg.active{background:linear-gradient(90deg,#8B7355,#C5B5A0)}
.step-node{
  width:28px;height:28px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:700;letter-spacing:.3px;
  border:2px solid #E8E2D9;background:#F7F4EF;color:#A89880;
  transition:all .3s;flex-shrink:0;
}
.step-node.done{background:#8B7355;border-color:#8B7355;color:#fff}
.step-node.active{background:#2C2416;border-color:#2C2416;color:#F7F4EF}
</style>

<div style="background:#F7F4EF;min-height:100vh;display:flex;flex-direction:column">

  <!-- HEADER -->
  <header style="background:#FFFFFF;border-bottom:1px solid #E8E2D9;padding:0 40px">
    <div style="max-width:1100px;margin:0 auto;height:64px;display:flex;align-items:center;justify-content:space-between">

      <!-- Brand -->
      <div style="display:flex;align-items:center;gap:10px">
        <div style="width:34px;height:34px;border-radius:10px;background:#2C2416;display:flex;align-items:center;justify-content:center">
          <svg width="16" height="16" viewBox="0 0 20 20" fill="none">
            <path d="M10 3L4 7V13L10 17L16 13V7L10 3Z" stroke="#F7F4EF" stroke-width="1.6" fill="none"/>
            <circle cx="10" cy="10" r="2.5" fill="#F7F4EF"/>
          </svg>
        </div>
        <div>
          <div style="font-family:'Instrument Serif',serif;font-size:18px;color:#2C2416;line-height:1">DIGNIFY</div>
          <div style="font-size:10px;font-weight:500;letter-spacing:1.8px;color:#A89880;text-transform:uppercase;line-height:1;margin-top:1px">Financial Identity</div>
        </div>
      </div>

      <!-- Step progress -->
      <div style="display:flex;align-items:center;gap:16px">
        <div style="display:flex;align-items:center;gap:6px">
          <div class="step-node done" style="font-size:9px">✓</div>
          <div class="step-seg done" style="width:28px"></div>
          <div class="step-node active">1</div>
          <div class="step-seg" style="width:28px"></div>
          <div class="step-node">2</div>
          <div class="step-seg" style="width:28px"></div>
          <div class="step-node">3</div>
          <div class="step-seg" style="width:28px"></div>
          <div class="step-node">4</div>
        </div>
        <div style="font-size:12px;font-weight:500;color:#A89880;letter-spacing:.3px;border-left:1px solid #E8E2D9;padding-left:16px">STEP 1 OF 4</div>
      </div>

      <!-- Right nav -->
      <div style="display:flex;align-items:center;gap:20px">
        <a href="#" style="font-size:13px;font-weight:500;color:#A89880;text-decoration:none;letter-spacing:.2px">Already registered?</a>
        <a href="#" style="font-size:13px;font-weight:600;color:#2C2416;text-decoration:none;letter-spacing:.2px;border-bottom:1.5px solid #2C2416;padding-bottom:1px">SIGN IN</a>
      </div>

    </div>
  </header>

  <!-- MAIN -->
  <main style="flex:1;display:flex;align-items:center;justify-content:center;padding:52px 24px">
    <div style="width:100%;max-width:600px">

      <!-- Page heading -->
      <div class="page-enter" style="margin-bottom:36px">
        <div style="display:inline-flex;align-items:center;gap:8px;background:#EDE5D8;border-radius:6px;padding:5px 12px;margin-bottom:18px">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="5.5" stroke="#8B7355"/><path d="M4 6h4M6 4v4" stroke="#8B7355" stroke-linecap="round"/></svg>
          <span style="font-size:10px;font-weight:700;letter-spacing:1.6px;text-transform:uppercase;color:#7A6245">Personalise</span>
        </div>
        <h1 style="font-family:'Instrument Serif',serif;font-size:38px;color:#2C2416;line-height:1.15;margin-bottom:8px">Choose Your Language</h1>
        <p style="font-size:15px;font-weight:400;color:#A89880;line-height:1.6;max-width:420px">
          Your score, schemes, and financial passport will all appear in the language you choose.
        </p>
      </div>

      <!-- Card shell -->
      <div class="a2" style="background:#FFFFFF;border:1px solid #E8E2D9;border-radius:20px;padding:32px">

        <div style="font-size:10px;font-weight:700;letter-spacing:1.8px;text-transform:uppercase;color:#C5B5A0;margin-bottom:20px">Select one language</div>

        <!-- Top row: 3 cards -->
        <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:12px">

          <div class="lang-card" id="card-en" onclick="pick('en')">
            <div style="width:36px;height:36px;border-radius:50%;background:#F5F0E8;display:flex;align-items:center;justify-content:center">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="6" width="18" height="12" rx="2" fill="#E8E2D9"/><path d="M3 9h18M3 15h18M12 6v12" stroke="#A89880" stroke-width="1.2"/></svg>
            </div>
            <div class="script-text" style="font-family:'DM Sans',sans-serif">English</div>
            <div class="lang-label">English</div>
            <div class="lang-code-pill">EN</div>
          </div>

          <div class="lang-card" id="card-hi" onclick="pick('hi')">
            <div style="width:36px;height:36px;border-radius:50%;background:#F5F0E8;display:flex;align-items:center;justify-content:center">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8" stroke="#A89880" stroke-width="1.2"/><path d="M8 12h8M12 8v8" stroke="#A89880" stroke-width="1.2" stroke-linecap="round"/></svg>
            </div>
            <div class="script-text" style="font-family:'Noto Sans Devanagari',sans-serif">हिंदी</div>
            <div class="lang-label">Hindi</div>
            <div class="lang-code-pill">HI</div>
          </div>

          <div class="lang-card" id="card-ta" onclick="pick('ta')">
            <div style="width:36px;height:36px;border-radius:50%;background:#F5F0E8;display:flex;align-items:center;justify-content:center">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M5 8c0 5 14 5 14 0" stroke="#A89880" stroke-width="1.2" stroke-linecap="round"/><path d="M5 12h14M8 16h8" stroke="#A89880" stroke-width="1.2" stroke-linecap="round"/></svg>
            </div>
            <div class="script-text" style="font-family:'Noto Sans Tamil',sans-serif">தமிழ்</div>
            <div class="lang-label">Tamil</div>
            <div class="lang-code-pill">TA</div>
          </div>

        </div>

        <!-- Bottom row: 2 cards centered -->
        <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-bottom:28px">

          <div class="lang-card" id="card-te" onclick="pick('te')">
            <div style="width:36px;height:36px;border-radius:50%;background:#F5F0E8;display:flex;align-items:center;justify-content:center">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M6 8h12M6 12h10M6 16h8" stroke="#A89880" stroke-width="1.4" stroke-linecap="round"/></svg>
            </div>
            <div class="script-text" style="font-family:'Noto Sans Telugu',sans-serif">తెలుగు</div>
            <div class="lang-label">Telugu</div>
            <div class="lang-code-pill">TE</div>
          </div>

          <div class="lang-card" id="card-kn" onclick="pick('kn')">
            <div style="width:36px;height:36px;border-radius:50%;background:#F5F0E8;display:flex;align-items:center;justify-content:center">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M7 7c3-2 8-2 10 2s-1 8-5 9-8-1-9-5" stroke="#A89880" stroke-width="1.3" stroke-linecap="round"/><path d="M7 14l2 2 4-4" stroke="#A89880" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
            <div class="script-text" style="font-family:'Noto Sans Kannada',sans-serif">ಕನ್ನಡ</div>
            <div class="lang-label">Kannada</div>
            <div class="lang-code-pill">KN</div>
          </div>

        </div>

        <!-- Confirmation line -->
        <div id="confirm-line" style="min-height:40px;display:flex;align-items:center;justify-content:center;margin-bottom:20px">
          <div style="display:flex;align-items:center;gap:10px;background:#F7F4EF;border:1px dashed #E8E2D9;border-radius:10px;padding:10px 20px;width:100%;justify-content:center">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" stroke="#C5B5A0" stroke-width="1.2"/><path d="M4.5 7l2 2 3-3" stroke="#C5B5A0" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            <span id="confirm-text" style="font-size:13px;font-weight:400;color:#C5B5A0;letter-spacing:.2px">No language selected yet</span>
          </div>
        </div>

        <!-- Button -->
        <button class="btn btn-primary" id="main-btn" onclick="proceed()" disabled>
          <span id="btn-label">SELECT A LANGUAGE TO CONTINUE</span>
        </button>

      </div>

      <!-- Footer note -->
      <div class="a3" style="display:flex;justify-content:center;gap:32px;margin-top:24px">
        <div style="display:flex;align-items:center;gap:7px">
          <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><rect x="1" y="4" width="12" height="9" rx="2" stroke="#C5B5A0" stroke-width="1.2"/><path d="M5 4V3a2 2 0 014 0v1" stroke="#C5B5A0" stroke-width="1.2"/></svg>
          <span style="font-size:12px;color:#C5B5A0;font-weight:400">Changeable in settings</span>
        </div>
        <div style="display:flex;align-items:center;gap:7px">
          <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" stroke="#C5B5A0" stroke-width="1.2"/><path d="M4 7l2 2 4-4" stroke="#C5B5A0" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <span style="font-size:12px;color:#C5B5A0;font-weight:400">AI responses in your script</span>
        </div>
        <div style="display:flex;align-items:center;gap:7px">
          <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M2 7c0-2.8 2.2-5 5-5s5 2.2 5 5-2.2 5-5 5-5-2.2-5-5z" stroke="#C5B5A0" stroke-width="1.2"/><path d="M7 4v3l2 2" stroke="#C5B5A0" stroke-width="1.2" stroke-linecap="round"/></svg>
          <span style="font-size:12px;color:#C5B5A0;font-weight:400">All 5 languages supported</span>
        </div>
      </div>

    </div>
  </main>

</div>

<script>
const LANGS={
  en:{label:'English',native:'English',confirm:'Everything will appear in English.',font:'DM Sans'},
  hi:{label:'Hindi',native:'हिंदी',confirm:'सब कुछ हिंदी में दिखेगा।',font:'Noto Sans Devanagari'},
  ta:{label:'Tamil',native:'தமிழ்',confirm:'எல்லாமே தமிழில் தெரியும்.',font:'Noto Sans Tamil'},
  te:{label:'Telugu',native:'తెలుగు',confirm:'అన్నీ తెలుగులో కనిపిస్తాయి.',font:'Noto Sans Telugu'},
  kn:{label:'Kannada',native:'ಕನ್ನಡ',confirm:'ಎಲ್ಲವೂ ಕನ್ನಡದಲ್ಲಿ ತೋರಿಸಲಾಗುತ್ತದೆ.',font:'Noto Sans Kannada'},
};
let current=null;

function pick(code){
  if(current===code)return;
  if(current){
    const prev=document.getElementById('card-'+current);
    prev.classList.remove('selected');
    const cb=prev.querySelector('.check-dot');
    if(cb)cb.remove();
  }
  current=code;
  const card=document.getElementById('card-'+code);
  card.classList.add('selected');
  const dot=document.createElement('div');
  dot.className='check-dot';
  dot.innerHTML='<svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2 5l2.5 2.5 3.5-3.5" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  card.appendChild(dot);
  const lang=LANGS[code];
  const confirmLine=document.getElementById('confirm-line');
  confirmLine.innerHTML=`<div style="display:flex;align-items:center;gap:10px;background:#F5F0E8;border:1px solid #E8E2D9;border-radius:10px;padding:10px 20px;width:100%;justify-content:center"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" fill="#8B7355"/><path d="M4.5 7l2 2 3-3" stroke="#fff" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg><span style="font-size:13px;font-weight:500;color:#7A6245;font-family:'${lang.font}',sans-serif">${lang.native}</span><span style="font-size:13px;color:#A89880;margin:0 4px">·</span><span style="font-size:13px;color:#A89880">${lang.confirm}</span></div>`;
  const btn=document.getElementById('main-btn');
  btn.disabled=false;
  document.getElementById('btn-label').textContent=`CONTINUE IN ${lang.label.toUpperCase()} →`;
}

function proceed(){
  if(!current)return;
  const btn=document.getElementById('main-btn');
  btn.disabled=true;
  document.getElementById('btn-label').textContent='SAVING YOUR PREFERENCE...';
  btn.style.background='#8B7355';
  setTimeout(()=>{
    document.getElementById('btn-label').textContent='✓ LANGUAGE SAVED — REDIRECTING';
    btn.style.background='#3B6D11';
  },1000);
}
</script>
