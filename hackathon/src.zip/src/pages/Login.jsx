
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&family=Instrument+Serif:ital@0;1&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:#F8FAFC;min-height:100vh;-webkit-font-smoothing:antialiased;color:#0F172A}

@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
@keyframes slideIn{from{opacity:0;transform:translateX(-10px)}to{opacity:1;transform:translateX(0)}}
@keyframes starPop{0%{transform:scale(0)}70%{transform:scale(1.3)}100%{transform:scale(1)}}

.a1{animation:fadeUp .5s ease both .05s}
.a2{animation:fadeUp .5s ease both .12s}
.a3{animation:fadeUp .5s ease both .19s}
.a4{animation:fadeUp .5s ease both .26s}
.a5{animation:fadeUp .5s ease both .33s}

.field-group{display:flex;flex-direction:column;gap:6px}
.field-label{
  font-size:11px;font-weight:700;letter-spacing:1.4px;
  text-transform:uppercase;color:#64748B;
}
.field-label span{color:#E11D48;margin-left:2px;font-size:13px}
.field-input{
  width:100%;height:46px;padding:0 14px;
  background:#FFFFFF;
  border:1.5px solid #E2E8F0;
  border-radius:10px;
  font-family:'DM Sans',sans-serif;font-size:14px;font-weight:400;color:#0F172A;
  outline:none;transition:border-color .2s,box-shadow .2s;
  appearance:none;-webkit-appearance:none;
}
.field-input:hover{border-color:#CBD5E1}
.field-input:focus{border-color:#2563EB;box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.field-input.error{border-color:#E11D48;box-shadow:0 0 0 3px rgba(225,29,72,.07)}
select.field-input{cursor:pointer;background-image:url("data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%2364748B' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;padding-right:36px}
.error-msg{font-size:11px;color:#E11D48;font-weight:500;display:flex;align-items:center;gap:4px;animation:slideIn .2s ease}

.section-card{
  background:#FFFFFF;border:1px solid #E2E8F0;
  border-radius:16px;overflow:hidden;
}
.section-header{
  padding:18px 24px 16px;
  border-bottom:1px solid #F1F5F9;
  display:flex;align-items:center;gap:12px;
}
.section-num{
  width:28px;height:28px;border-radius:8px;
  background:#0F172A;color:#F8FAFC;
  font-size:12px;font-weight:700;
  display:flex;align-items:center;justify-content:center;
  letter-spacing:.3px;flex-shrink:0;
}
.section-num.done{background:#059669;color:#fff}
.section-title{font-size:13px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:#0F172A}
.section-sub{font-size:12px;color:#94A3B8;margin-top:1px;font-weight:400}
.section-body{padding:24px}
.field-grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.field-grid-1{display:grid;grid-template-columns:1fr;gap:16px}

.star-row{display:flex;gap:4px;align-items:center}
.star{
  width:28px;height:28px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  border-radius:6px;transition:background .15s;
}
.star:hover{background:#FEF3C7}
.star svg{transition:all .15s}

.progress-stepper{display:flex;align-items:center;gap:0}
.pstep{
  display:flex;align-items:center;gap:8px;
  font-size:11px;font-weight:600;letter-spacing:.8px;
  text-transform:uppercase;color:#94A3B8;
  transition:color .3s;
}
.pstep.active{color:#2563EB}
.pstep.done{color:#059669}
.pstep-dot{
  width:24px;height:24px;border-radius:50%;
  border:1.5px solid #E2E8F0;background:#fff;
  display:flex;align-items:center;justify-content:center;
  font-size:10px;font-weight:700;color:#94A3B8;
  transition:all .3s;flex-shrink:0;
}
.pstep.active .pstep-dot{border-color:#2563EB;background:#EFF6FF;color:#2563EB}
.pstep.done .pstep-dot{border-color:#059669;background:#ECFDF5;color:#059669}
.pstep-line{width:32px;height:1.5px;background:#E2E8F0;flex-shrink:0}
.pstep-line.done{background:#059669}

.submit-btn{
  width:100%;height:52px;background:#0F172A;color:#F8FAFC;
  border:none;border-radius:12px;
  font-family:'DM Sans',sans-serif;font-size:14px;font-weight:700;
  letter-spacing:.6px;text-transform:uppercase;cursor:pointer;
  transition:all .2s;display:flex;align-items:center;justify-content:center;gap:10px;
}
.submit-btn:hover{background:#1E293B;transform:translateY(-1px);box-shadow:0 8px 24px rgba(15,23,42,.2)}
.submit-btn:active{transform:translateY(0)}
.submit-btn:disabled{background:#94A3B8;cursor:not-allowed;transform:none;box-shadow:none}

.aadhaar-hint{
  display:flex;align-items:center;gap:6px;
  background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;
  padding:7px 12px;margin-top:6px;
}
.tag-pill{
  display:inline-flex;align-items:center;gap:5px;
  background:#EFF6FF;border-radius:6px;padding:3px 10px;
  font-size:11px;font-weight:600;letter-spacing:.5px;color:#1D4ED8;
}
</style>

<div style="background:#F8FAFC;min-height:100vh;padding-bottom:60px">

  <!-- NAV -->
  <nav style="background:#FFFFFF;border-bottom:1px solid #E2E8F0;height:62px;display:flex;align-items:center;padding:0 40px;position:sticky;top:0;z-index:50">
    <div style="max-width:1100px;width:100%;margin:0 auto;display:flex;align-items:center;justify-content:space-between">
      <div style="display:flex;align-items:center;gap:10px">
        <div style="width:32px;height:32px;border-radius:9px;background:#0F172A;display:flex;align-items:center;justify-content:center">
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none"><path d="M10 3L4 7V13L10 17L16 13V7L10 3Z" stroke="#F8FAFC" stroke-width="1.6" fill="none"/><circle cx="10" cy="10" r="2.2" fill="#F8FAFC"/></svg>
        </div>
        <div>
          <div style="font-family:'Instrument Serif',serif;font-size:17px;color:#0F172A;line-height:1;letter-spacing:.5px">DIGNIFY</div>
          <div style="font-size:9px;font-weight:600;letter-spacing:2px;color:#94A3B8;text-transform:uppercase;line-height:1;margin-top:1px">Financial Identity</div>
        </div>
      </div>

      <!-- Stepper -->
      <div class="progress-stepper">
        <div class="pstep done"><div class="pstep-dot">✓</div></div>
        <div class="pstep-line done"></div>
        <div class="pstep active"><div class="pstep-dot">2</div><span>Profile</span></div>
        <div class="pstep-line"></div>
        <div class="pstep"><div class="pstep-dot">3</div><span style="display:none">Upload</span></div>
        <div class="pstep-line"></div>
        <div class="pstep"><div class="pstep-dot">4</div></div>
        <div class="pstep-line"></div>
        <div class="pstep"><div class="pstep-dot">5</div></div>
      </div>

      <a href="#" style="font-size:13px;font-weight:500;color:#64748B;text-decoration:none">Already have a profile? <span style="color:#2563EB;font-weight:600;border-bottom:1.5px solid #2563EB;padding-bottom:1px">Login</span></a>
    </div>
  </nav>

  <!-- PAGE -->
  <div style="max-width:880px;margin:0 auto;padding:44px 24px 0">

    <!-- Header block -->
    <div class="a1" style="margin-bottom:36px;display:flex;align-items:flex-end;justify-content:space-between;gap:20px">
      <div>
        <div style="display:inline-flex;align-items:center;gap:7px;background:#EFF6FF;border-radius:6px;padding:4px 12px;margin-bottom:14px">
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M6 1v10M1 6h10" stroke="#2563EB" stroke-width="1.6" stroke-linecap="round"/></svg>
          <span style="font-size:10px;font-weight:700;letter-spacing:1.8px;text-transform:uppercase;color:#1D4ED8">Create Your Profile</span>
        </div>
        <h1 style="font-family:'Instrument Serif',serif;font-size:34px;color:#0F172A;line-height:1.15;letter-spacing:-.2px">
          Build Your Financial Identity
        </h1>
        <p style="font-size:14px;color:#64748B;margin-top:8px;line-height:1.65;max-width:460px">Tell us about yourself — this becomes the foundation of your <em>WorkProof Score</em> and scheme eligibility.</p>
      </div>
      <div style="flex-shrink:0;text-align:right">
        <div style="font-size:10px;font-weight:700;letter-spacing:1.4px;text-transform:uppercase;color:#94A3B8;margin-bottom:6px">Completion</div>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:120px;height:6px;background:#E2E8F0;border-radius:99px;overflow:hidden"><div id="prog-bar" style="height:100%;width:0%;background:linear-gradient(90deg,#2563EB,#3B82F6);border-radius:99px;transition:width .4s ease"></div></div>
          <span id="prog-pct" style="font-size:13px;font-weight:700;color:#2563EB;min-width:30px">0%</span>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 300px;gap:20px;align-items:start">

      <!-- LEFT: form cards -->
      <div style="display:flex;flex-direction:column;gap:16px">

        <!-- Card 1: Identity -->
        <div class="section-card a2">
          <div class="section-header">
            <div class="section-num" id="sn1">01</div>
            <div><div class="section-title">Identity</div><div class="section-sub">Your name and secure Aadhaar verification</div></div>
          </div>
          <div class="section-body">
            <div class="field-grid-1" style="gap:16px">
              <div class="field-group">
                <label class="field-label">Full Name <span>*</span></label>
                <input class="field-input" type="text" placeholder="Ramesh Kumar" id="f-name" oninput="validate('f-name');updateProgress()">
                <div class="error-msg" id="e-name" style="display:none">
                  <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="5.5" stroke="#E11D48"/><path d="M6 4v2.5M6 8h.01" stroke="#E11D48" stroke-linecap="round"/></svg>
                  Enter at least 2 characters
                </div>
              </div>
              <div class="field-group">
                <label class="field-label">Aadhaar Number <span>*</span></label>
                <input class="field-input" type="text" placeholder="XXXX  XXXX  XXXX" maxlength="14" id="f-aadhaar" oninput="formatAadhaar(this);updateProgress()" style="font-family:'DM Sans',monospace;letter-spacing:2px">
                <div class="aadhaar-hint">
                  <svg width="12" height="12" viewBox="0 0 14 14" fill="none"><rect x="1" y="4" width="12" height="9" rx="2" stroke="#059669" stroke-width="1.2"/><path d="M5 4V3a2 2 0 014 0v1" stroke="#059669" stroke-width="1.2"/></svg>
                  <span style="font-size:11px;color:#059669;font-weight:500">Stored with one-way encryption — never shared</span>
                </div>
                <div class="error-msg" id="e-aadhaar" style="display:none">
                  <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="5.5" stroke="#E11D48"/><path d="M6 4v2.5M6 8h.01" stroke="#E11D48" stroke-linecap="round"/></svg>
                  Must be exactly 12 digits
                </div>
              </div>
              <div class="field-group">
                <label class="field-label">Mobile Number <span>*</span></label>
                <input class="field-input" type="tel" placeholder="9876543210" maxlength="10" id="f-phone" oninput="updateProgress()">
              </div>
            </div>
          </div>
        </div>

        <!-- Card 2: Location & Work -->
        <div class="section-card a3">
          <div class="section-header">
            <div class="section-num" id="sn2">02</div>
            <div><div class="section-title">Location & Work</div><div class="section-sub">Where you work and what you do</div></div>
          </div>
          <div class="section-body">
            <div class="field-grid-2" style="gap:16px">
              <div class="field-group">
                <label class="field-label">State <span>*</span></label>
                <select class="field-input" id="f-state" onchange="updateProgress()">
                  <option value="">Select state</option>
                  <option>Andhra Pradesh</option><option>Arunachal Pradesh</option><option>Assam</option><option>Bihar</option><option>Chhattisgarh</option><option>Goa</option><option>Gujarat</option><option>Haryana</option><option>Himachal Pradesh</option><option>Jharkhand</option><option>Karnataka</option><option>Kerala</option><option>Madhya Pradesh</option><option>Maharashtra</option><option>Manipur</option><option>Meghalaya</option><option>Mizoram</option><option>Nagaland</option><option>Odisha</option><option>Punjab</option><option>Rajasthan</option><option>Sikkim</option><option>Tamil Nadu</option><option>Telangana</option><option>Tripura</option><option>Uttar Pradesh</option><option>Uttarakhand</option><option>West Bengal</option><option>Delhi</option><option>Puducherry</option><option>Chandigarh</option><option>Ladakh</option>
                </select>
              </div>
              <div class="field-group">
                <label class="field-label">Occupation <span>*</span></label>
                <select class="field-input" id="f-occ" onchange="updateProgress()">
                  <option value="">Select occupation</option>
                  <option value="street_vendor">Street Vendor</option>
                  <option value="domestic_worker">Domestic Worker</option>
                  <option value="construction">Construction Worker</option>
                  <option value="driver">Auto / Taxi Driver</option>
                  <option value="delivery">Delivery Agent</option>
                  <option value="farmer">Farmer / Agricultural</option>
                  <option value="migrant">Migrant Worker</option>
                  <option value="other">Other Informal Work</option>
                </select>
              </div>
              <div class="field-group">
                <label class="field-label">Years of Work <span>*</span></label>
                <input class="field-input" type="number" min="0" max="50" placeholder="5" id="f-years" oninput="updateProgress()">
              </div>
              <div class="field-group">
                <label class="field-label">Gig Platform</label>
                <select class="field-input" id="f-gig" onchange="toggleRating();updateProgress()">
                  <option value="none">None</option>
                  <option value="swiggy">Swiggy</option>
                  <option value="zomato">Zomato</option>
                  <option value="ola">Ola</option>
                  <option value="uber">Uber</option>
                  <option value="urban_company">Urban Company</option>
                  <option value="dunzo">Dunzo</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <!-- Rating row — hidden by default -->
            <div id="rating-row" style="display:none;margin-top:16px;animation:fadeUp .3s ease">
              <div class="field-group">
                <label class="field-label">Your Platform Rating</label>
                <div style="display:flex;align-items:center;gap:16px;margin-top:4px">
                  <div class="star-row" id="star-row">
                    <div class="star" onclick="setRating(1)" data-v="1"><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 2l2.6 5.3 5.8.8-4.2 4.1 1 5.8L12 15.3l-5.2 2.7 1-5.8L3.6 8.1l5.8-.8L12 2z" stroke="#E2E8F0" stroke-width="1.4" fill="#E2E8F0"/></svg></div>
                    <div class="star" onclick="setRating(2)" data-v="2"><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 2l2.6 5.3 5.8.8-4.2 4.1 1 5.8L12 15.3l-5.2 2.7 1-5.8L3.6 8.1l5.8-.8L12 2z" stroke="#E2E8F0" stroke-width="1.4" fill="#E2E8F0"/></svg></div>
                    <div class="star" onclick="setRating(3)" data-v="3"><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 2l2.6 5.3 5.8.8-4.2 4.1 1 5.8L12 15.3l-5.2 2.7 1-5.8L3.6 8.1l5.8-.8L12 2z" stroke="#E2E8F0" stroke-width="1.4" fill="#E2E8F0"/></svg></div>
                    <div class="star" onclick="setRating(4)" data-v="4"><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 2l2.6 5.3 5.8.8-4.2 4.1 1 5.8L12 15.3l-5.2 2.7 1-5.8L3.6 8.1l5.8-.8L12 2z" stroke="#E2E8F0" stroke-width="1.4" fill="#E2E8F0"/></svg></div>
                    <div class="star" onclick="setRating(5)" data-v="5"><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 2l2.6 5.3 5.8.8-4.2 4.1 1 5.8L12 15.3l-5.2 2.7 1-5.8L3.6 8.1l5.8-.8L12 2z" stroke="#E2E8F0" stroke-width="1.4" fill="#E2E8F0"/></svg></div>
                  </div>
                  <span id="rating-val" style="font-size:22px;font-weight:700;color:#0F172A;min-width:28px">—</span>
                  <span style="font-size:12px;color:#94A3B8">out of 5.0</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Submit -->
        <div class="a4">
          <button class="submit-btn" id="submit-btn" onclick="handleSubmit()">
            <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M10 3L4 7V13L10 17L16 13V7L10 3Z" stroke="#F8FAFC" stroke-width="1.6" fill="none"/><circle cx="10" cy="10" r="2.2" fill="#F8FAFC"/></svg>
            <span id="btn-txt">Create My Profile</span>
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8h10M9 4l4 4-4 4" stroke="#F8FAFC" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <p style="text-align:center;font-size:12px;color:#94A3B8;margin-top:12px">By continuing you agree to our <span style="color:#2563EB;cursor:pointer;border-bottom:1px solid #BFDBFE">Terms of Service</span> and <span style="color:#2563EB;cursor:pointer;border-bottom:1px solid #BFDBFE">Privacy Policy</span></p>
        </div>

      </div>

      <!-- RIGHT: sidebar info -->
      <div style="display:flex;flex-direction:column;gap:14px;position:sticky;top:82px">

        <!-- What you unlock -->
        <div class="section-card a2" style="overflow:visible">
          <div style="padding:18px 20px 14px;border-bottom:1px solid #F1F5F9">
            <div style="font-size:10px;font-weight:700;letter-spacing:1.6px;text-transform:uppercase;color:#94A3B8;margin-bottom:4px">What you unlock</div>
            <div style="font-family:'Instrument Serif',serif;font-size:18px;color:#0F172A">Your Financial Passport</div>
          </div>
          <div style="padding:16px 20px;display:flex;flex-direction:column;gap:11px">
            <div style="display:flex;align-items:flex-start;gap:10px">
              <div style="width:22px;height:22px;border-radius:6px;background:#ECFDF5;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px">
                <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M2 6l2.5 2.5 5.5-5" stroke="#059669" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </div>
              <span style="font-size:13px;color:#475569;line-height:1.5">WorkProof Score (0–850) based on UPI history</span>
            </div>
            <div style="display:flex;align-items:flex-start;gap:10px">
              <div style="width:22px;height:22px;border-radius:6px;background:#ECFDF5;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px">
                <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M2 6l2.5 2.5 5.5-5" stroke="#059669" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </div>
              <span style="font-size:13px;color:#475569;line-height:1.5">Matched government scheme eligibility</span>
            </div>
            <div style="display:flex;align-items:flex-start;gap:10px">
              <div style="width:22px;height:22px;border-radius:6px;background:#ECFDF5;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px">
                <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M2 6l2.5 2.5 5.5-5" stroke="#059669" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </div>
              <span style="font-size:13px;color:#475569;line-height:1.5">Downloadable 1-page financial document</span>
            </div>
            <div style="display:flex;align-items:flex-start;gap:10px">
              <div style="width:22px;height:22px;border-radius:6px;background:#ECFDF5;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px">
                <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M2 6l2.5 2.5 5.5-5" stroke="#059669" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </div>
              <span style="font-size:13px;color:#475569;line-height:1.5">AI explanation in your language</span>
            </div>
          </div>
        </div>

        <!-- Privacy card -->
        <div style="background:#0F172A;border-radius:14px;padding:18px 20px">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
            <div style="width:28px;height:28px;border-radius:8px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center">
              <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><rect x="1" y="5" width="12" height="8" rx="2" stroke="#94A3B8" stroke-width="1.2"/><path d="M5 5V4a2 2 0 014 0v1" stroke="#94A3B8" stroke-width="1.2"/></svg>
            </div>
            <div style="font-size:11px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:#F8FAFC">Privacy First</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:9px">
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:5px;height:5px;border-radius:50%;background:#3B82F6;flex-shrink:0"></div>
              <span style="font-size:12px;color:#94A3B8;line-height:1.4">Aadhaar hashed — never stored raw</span>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:5px;height:5px;border-radius:50%;background:#3B82F6;flex-shrink:0"></div>
              <span style="font-size:12px;color:#94A3B8;line-height:1.4">Data never sold to third parties</span>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:5px;height:5px;border-radius:50%;background:#3B82F6;flex-shrink:0"></div>
              <span style="font-size:12px;color:#94A3B8;line-height:1.4">UPI PDF deleted after scoring</span>
            </div>
          </div>
        </div>

        <!-- Already registered -->
        <div style="background:#F1F5F9;border-radius:12px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between">
          <div>
            <div style="font-size:12px;font-weight:600;color:#475569">Already registered?</div>
            <div style="font-size:11px;color:#94A3B8;margin-top:2px">Log in with Aadhaar + phone</div>
          </div>
          <a href="#" style="font-size:12px;font-weight:700;color:#2563EB;text-decoration:none;white-space:nowrap;border-bottom:1.5px solid #BFDBFE;padding-bottom:1px">Login →</a>
        </div>

      </div>
    </div>
  </div>

</div>

<script>
let rating=0;
const required=['f-name','f-aadhaar','f-phone','f-state','f-occ','f-years'];

function formatAadhaar(el){
  let v=el.value.replace(/\D/g,'').substring(0,12);
  let fmt='';
  for(let i=0;i<v.length;i++){if(i>0&&i%4===0)fmt+='  ';fmt+=v[i];}
  el.value=fmt;
  validate('f-aadhaar');
}

function validate(id){
  const el=document.getElementById(id);
  const err=document.getElementById('e-'+id);
  if(!err)return true;
  let ok=true;
  if(id==='f-name'){ok=el.value.trim().length>=2}
  if(id==='f-aadhaar'){ok=el.value.replace(/\s/g,'').length===12}
  err.style.display=ok?'none':'flex';
  el.classList.toggle('error',!ok);
  return ok;
}

function toggleRating(){
  const v=document.getElementById('f-gig').value;
  document.getElementById('rating-row').style.display=v&&v!=='none'?'block':'none';
}

function setRating(n){
  rating=n;
  document.getElementById('rating-val').textContent=n+'.0';
  document.querySelectorAll('.star').forEach((s,i)=>{
    const filled=i<n;
    s.innerHTML=`<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 2l2.6 5.3 5.8.8-4.2 4.1 1 5.8L12 15.3l-5.2 2.7 1-5.8L3.6 8.1l5.8-.8L12 2z" stroke="${filled?'#F59E0B':'#E2E8F0'}" stroke-width="1.4" fill="${filled?'#FEF3C7':'#E2E8F0'}"/></svg>`;
    if(filled&&i===n-1){s.querySelector('svg').style.transform='scale(1.18)';s.querySelector('path').setAttribute('fill','#F59E0B')}
  });
}

function updateProgress(){
  let filled=0;
  required.forEach(id=>{
    const el=document.getElementById(id);
    if(el&&el.value.trim().length>0)filled++;
  });
  const pct=Math.round((filled/required.length)*100);
  document.getElementById('prog-bar').style.width=pct+'%';
  document.getElementById('prog-pct').textContent=pct+'%';
  const sn1=document.getElementById('sn1');
  const sn2=document.getElementById('sn2');
  const n=document.getElementById('f-name'),a=document.getElementById('f-aadhaar'),p=document.getElementById('f-phone');
  if(n.value.trim().length>=2&&a.value.replace(/\s/g,'').length===12&&p.value.length===10){
    sn1.classList.add('done');sn1.textContent='✓';}
  const s=document.getElementById('f-state'),o=document.getElementById('f-occ'),y=document.getElementById('f-years');
  if(s.value&&o.value&&y.value){sn2.classList.add('done');sn2.textContent='✓';}
}

function handleSubmit(){
  const btn=document.getElementById('submit-btn');
  const txt=document.getElementById('btn-txt');
  btn.disabled=true;
  txt.textContent='Creating your profile...';
  btn.style.background='#2563EB';
  let dots=0;
  const iv=setInterval(()=>{dots=(dots+1)%4;txt.textContent='Creating your profile'+'.'.repeat(dots);},400);
  setTimeout(()=>{
    clearInterval(iv);
    btn.style.background='#059669';
    txt.textContent='Profile created — moving to upload';
    btn.disabled=false;
  },2200);
}
</script>
